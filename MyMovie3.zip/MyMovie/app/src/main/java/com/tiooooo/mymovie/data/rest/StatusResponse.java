package com.tiooooo.mymovie.data.rest;

public enum StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
