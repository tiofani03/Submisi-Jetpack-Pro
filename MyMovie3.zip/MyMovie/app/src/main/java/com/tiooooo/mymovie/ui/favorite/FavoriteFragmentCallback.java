package com.tiooooo.mymovie.ui.favorite;

public interface FavoriteFragmentCallback {
}
