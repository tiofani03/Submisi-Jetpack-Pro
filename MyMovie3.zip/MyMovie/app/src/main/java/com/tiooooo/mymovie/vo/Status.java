package com.tiooooo.mymovie.vo;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING

}
